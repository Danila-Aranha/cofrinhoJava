package Trabalho;

import java.util.ArrayList; //importa a classe ArrayList para armazenamento de moedas

//demonstra a classe
public class Cofrinho {
    private ArrayList<Moeda> moedas;
    //construtor de classe
    public Cofrinho() {
        moedas = new ArrayList<>();
    }
    //add moedas
    public void adicionarMoeda(Moeda moeda) {
        moedas.add(moeda);
        System.out.println(moeda.getNome() + " moeda adicionada ao cofrinho!");
    }
    //removerá moedas
    public void removerMoeda(int index) {
        if (index >= 0 && index < moedas.size()) {
            Moeda removida = moedas.remove(index);
            System.out.println(removida.getNome() + " moeda removida do cofrinho!");
        } else {
            System.out.println("Número inválido!");
        }
    }
    //ordenará moedas
    public void listarMoedas() {
        if (moedas.isEmpty()) {
            System.out.println("Cofrinho vazio!");
        } else {
            System.out.println("Moedas no cofrinho:");
            for (int i = 0; i < moedas.size(); i++) {
                System.out.println(i + " - " + moedas.get(i));
            }
        }
    }
    //calculará total de dinheiro que tenha sido convertido para real
    public double calcularTotalEmReais() {
        double total = 0;
        for (Moeda moeda : moedas) {
            total += moeda.converterParaReal();
        }
        return total;
    }
}
	
