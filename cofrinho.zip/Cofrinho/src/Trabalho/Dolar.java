package Trabalho;
//também classe filha herdará de moedas
public class Dolar extends Moeda {
    private static final double VALOR_DOLAR = 5.7;

    public Dolar(double valor) {
        super(valor);
    }

//será convertida para Real   
    public double converterParaReal() {
        return valor * VALOR_DOLAR;
    }

    
    public String getNome() {
        return "Dólar";
    }
}