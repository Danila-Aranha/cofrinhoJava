package Trabalho;

public class Euro extends Moeda {
    private static final double VALOR_EURO = 5.9;

    public Euro(double valor) {
        super(valor);
    }

//moeda que será convertida para Real    
    public double converterParaReal() {
        return valor * VALOR_EURO;
    }

    
    public String getNome() {
        return "Euro";
    }
}

