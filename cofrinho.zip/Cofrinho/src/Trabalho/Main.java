package Trabalho;


import java.util.Scanner;

//classe principal
public class Main{
	
	//starta a execução do programa
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Cofrinho cofrinho = new Cofrinho();
        int opcao;
        
        //opções disponíveis do que pode ser feito ao utilzar o cofrinho de moedas
        do {
            System.out.println("Cofrinho de Moedas");
            System.out.println("1 - Adicionar moeda");
            System.out.println("2 - Remover moeda");
            System.out.println("3 - Listar moedas");
            System.out.println("4 - Calcular total em Real");
            System.out.println("0 - Sair");
            System.out.print("Escolha uma opção: ");
            
            opcao = scanner.nextInt();

            //estrutura para escolha de ação do usuário
            switch (opcao) {
                case 1:
                    System.out.println("Escolha moeda:");
                    System.out.println("1 - Real");
                    System.out.println("2 - Dólar");
                    System.out.println("3 - Euro");
                    int tipo = scanner.nextInt();
                    System.out.print("Digite o valor: ");
                    double valor = scanner.nextDouble();
                    
                    switch (tipo) {
                        case 1 -> cofrinho.adicionarMoeda(new Real(valor));
                        case 2 -> cofrinho.adicionarMoeda(new Dolar(valor));
                        case 3 -> cofrinho.adicionarMoeda(new Euro(valor));
                        default -> System.out.println("Tipo de moeda inválida!");
                    }
                    break;
                    
                case 2:
                    cofrinho.listarMoedas();
                    System.out.print("Digite moeda a ser remover: ");
                    int indice = scanner.nextInt();
                    cofrinho.removerMoeda(indice);
                    break;
                    
                case 3:
                    cofrinho.listarMoedas(); //mostra as moedas que foram add no cofrinho
                    break;
                    
                case 4:
                    System.out.printf("Total em Real: R$ %.2f\n", cofrinho.calcularTotalEmReais());
                    break;
                    
                case 0:
                    System.out.println("Volte Sempre E Com Mais Moedas...");
                    break;
                    
                default:
                    System.out.println("Opção inválida!");
            }
        } while (opcao != 0);

        scanner.close();
    }
}