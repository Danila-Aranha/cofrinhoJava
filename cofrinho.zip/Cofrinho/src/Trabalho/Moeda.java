package Trabalho;
//classe abstrata que serve de modelo para os tipos de moedas do cofrinho(mãe)
public abstract class Moeda {
    protected double valor;

    public Moeda(double valor) {
        this.valor = valor;
    }

    public abstract double converterParaReal();

    public abstract String getNome();

    @Override
    public String toString() {
        return getNome() + " - " + valor;
    }
}

