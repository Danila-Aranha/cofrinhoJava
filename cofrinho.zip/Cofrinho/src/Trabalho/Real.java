package Trabalho;
//extends é classe filha que herda da classe abstrata, mãe
public class Real extends Moeda {
    public Real(double valor) {
        super(valor);
    }

 //método de conversão   
    public double converterParaReal() {
        return valor;
    }

    
    public String getNome() {
        return "Real";
    }
}
